import { Entity, Column, PrimaryGeneratedColumn } from 'typeorm';

@Entity()
export class User {
  @PrimaryGeneratedColumn()
  id?: number;

  @Column()
  firstName: string;

  @Column()
  lastName?: string;

  @Column()
  login: string;

  @Column()
  password: string;

  @Column({ unique: true })
  email: string;

  @Column()
  phone: string;
  
  @Column()
  address: string;
  
  @Column()
  postcode: string;
  
  @Column()
  city: string;
  
  @Column()
  country: string;

  /* @Column({ default: true })
  isActive?: boolean; */
}