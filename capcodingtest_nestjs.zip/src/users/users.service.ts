import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { CreateUserDto } from './dto/create-user.dto';
import { User } from './user.entity';
import * as bcrypt from 'bcrypt';

@Injectable()
export class UsersService {
  constructor(
    @InjectRepository(User)
    private readonly usersRepository: Repository<User>,
  ) {}

  async create(createUserDto: CreateUserDto): Promise<User> {
    const user = new User();
    user.firstName = createUserDto.firstName;
    user.lastName = createUserDto.lastName;
    user.login = createUserDto.login;
    user.password = await bcrypt.hash(createUserDto.password, 10);
    user.email = createUserDto.email;
    user.phone = createUserDto.phone;
    user.address = createUserDto.address;
    user.postcode = createUserDto.postcode;
    user.city = createUserDto.city;
    user.country = createUserDto.country;

    return this.usersRepository.save(user);
  }

  async update (
    id: number,
    item: User,
  ): Promise<User> {
    if (!id)
      throw new Error(`update error: id is empty.`);
    try {
      const userToUpdate = await this.findOne(id);

      if(item.firstName){
        userToUpdate.firstName = item.firstName;
      }
      if(item.lastName){
        userToUpdate.lastName = item.lastName;
      }
      if(item.login){
        userToUpdate.login = item.login;
      }
      if(item.password){
        userToUpdate.password = await bcrypt.hash(item.password, 10);
      }
      if(item.email){
        userToUpdate.email = item.email;
      }
      if(item.phone){
        userToUpdate.phone = item.phone;
      }
      if(item.address){
        userToUpdate.address = item.address;
      }
      if(item.postcode){
        userToUpdate.postcode = item.postcode;
      }
      if(item.city){
        userToUpdate.city = item.city;
      }
      if(item.country){
        userToUpdate.country = item.country;
      }
      return this.usersRepository.save(userToUpdate);
    }
    catch (ex) {
      throw new Error(`Update error: ${ex.message}.`);
    }
  };

  async findAll(): Promise<User[]> {
    return this.usersRepository.find();
  }

  findOne(id: number): Promise<User> {
    return this.usersRepository.findOneBy({ id: id });
  }

  async remove(id: string): Promise<void> {
    await this.usersRepository.delete(id);
  }
}