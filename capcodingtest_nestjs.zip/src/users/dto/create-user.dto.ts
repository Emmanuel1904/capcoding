export class CreateUserDto {
    id?: number;
    firstName: string;
    lastName?: string;
    login: string;
    password: string;
    email: string;
    phone: string;
    address: string;
    postcode: string;
    city: string;
    country: string;
  }