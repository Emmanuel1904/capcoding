package com.example.capcoding

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
