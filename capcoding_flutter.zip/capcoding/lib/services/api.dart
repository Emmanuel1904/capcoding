import 'dart:convert';
import 'package:capcoding/models/user.dart';
import 'package:http/http.dart';

class ApiConstants {
  static String apiUrl = 'http://localhost:3000';
  static String usersEndpoint = '/users';
}

class ApiService {

  var url = Uri.parse(ApiConstants.apiUrl + ApiConstants.usersEndpoint);

  Future<List<User>> getUsers() async {
    Response res = await get(url);

    if (res.statusCode == 200) {
      List<dynamic> body = jsonDecode(res.body);
      List<User> users = body.map((dynamic item) => User.fromJson(item)).toList();
      return users;
    } else {
      throw "Failed to load users list";
    }
  }

  Future<User> getUserById(String id) async {
    var urlSingle = Uri.parse(ApiConstants.apiUrl + ApiConstants.usersEndpoint+'/$id');
    final response = await get(urlSingle);

    if (response.statusCode == 200) {
      return User.fromJson(json.decode(response.body));
    } else {
      throw Exception('Failed to load a user');
    }
  }

  Future<User> createUser(User user) async {
    Map data = {
      'firstName': user.firstName,
      'lastName': user.lastName,
      'login': user.login,
      'password': user.password,
      'email': user.email,
      'phone': user.phone,
      'address': user.address,
      'postcode': user.postcode,
      'city': user.city,
      'country': user.country,
    };

    final Response response = await post(
      url,
      headers: <String, String>{
        'Content-Type': 'application/json; charset=UTF-8',
      },
      body: jsonEncode(data),
    );
    if (response.statusCode == 200) {
      return User.fromJson(json.decode(response.body));
    } else {
      throw Exception('Failed to post user');
    }
  }

  Future<User> updateUser(int id, User user) async {
    Map data = {
      'firstName': user.firstName,
      'lastName': user.lastName,
      'login': user.login,
      'password': user.password,
      'email': user.email,
      'phone': user.phone,
      'address': user.address,
      'postcode': user.postcode,
      'city': user.city,
      'country': user.country,
    };
    var urlSingle = Uri.parse(ApiConstants.apiUrl + ApiConstants.usersEndpoint+'/$id');

    final Response response = await patch(
      urlSingle,
      headers: <String, String>{
        'Content-Type': 'application/json; charset=UTF-8',
      },
      body: jsonEncode(data),
    );
    if (response.statusCode == 200) {
      return User.fromJson(json.decode(response.body));
    } else {
      throw Exception('Failed to update a user');
    }
  }

  Future<void> deleteUser(String id) async {
    var urlSingle = Uri.parse(ApiConstants.apiUrl + ApiConstants.usersEndpoint+'/$id');
    Response res = await delete(urlSingle);

    if (res.statusCode == 200) {
      print("User deleted");
    } else {
      throw "Failed to delete a user.";
    }
  }

}