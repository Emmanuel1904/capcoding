class User {
  final int? index;
  final String firstName;
  final String? lastName;
  final String login;
  final String password;
  final String email;
  final String phone;
  final String address;
  final String postcode;
  final String city;
  final String country;

  User(
      {this.index,
      required this.firstName,
      this.lastName,
      required this.login,
      required this.password,
      required this.email,
      required this.phone,
      required this.address,
      required this.postcode,
      required this.city,
      required this.country});

  factory User.fromJson(Map<String, dynamic> json) {
    return User(
      index: json['id'] as int,
      firstName: json['firstName'] as String,
      lastName: json['lastName'] as String,
      login: json['login'] as String,
      password: json['password'] as String,
      email: json['email'] as String,
      phone: json['phone'] as String,
      address: json['address'] as String,
      postcode: json['postcode'] as String,
      city: json['city'] as String,
      country: json['country'] as String,
    );
  }

  @override
  String toString() {
    return 'User{firstName: $firstName, lastName: $lastName, login: $login, password: $password, email: $email, phone: $phone, address: $address, postcode: $postcode, city: $city, country: $country}';
  }
}