import 'package:flutter/material.dart';
import 'services/api.dart';
import 'edidatawidget.dart';
import 'models/user.dart';

class DetailWidget extends StatefulWidget {
  DetailWidget(this.users);

  final User users;

  @override
  _DetailWidgetState createState() => _DetailWidgetState();
}

class _DetailWidgetState extends State<DetailWidget> {
  _DetailWidgetState();

  final ApiService api = ApiService();

  _navigateToEditScreen (BuildContext context, User user) async {
    final result = await Navigator.push(
      context,
      MaterialPageRoute(builder: (context) => EditDataWidget(user)),
    );
  }

   Future<void> _confirmDialog() async {
    return showDialog<void>(
      context: context,
      barrierDismissible: false, // user must tap button!
      builder: (BuildContext context) {
        return AlertDialog(
          title: Text('Attention!'),
          content: SingleChildScrollView(
            child: ListBody(
              children: <Widget>[
                Text('Vous êtes sur le point de supprimer définitivement cet utilisateur. Confirmez-vous cette opération irréversible?'),
              ],
            ),
          ),
          actions: <Widget>[
            FlatButton(
              child: Text('Oui'),
              onPressed: () {
                api.deleteUser(widget.users.index.toString());
                Navigator.popUntil(context, ModalRoute.withName(Navigator.defaultRouteName));
              },
            ),
            FlatButton(
              child: const Text('Non'),
              onPressed: () {
                Navigator.of(context).pop();
              },
            ),
          ],
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Détail'),
      ),
      body: SingleChildScrollView(
        child: Container(
          padding: const EdgeInsets.all(20.0),
          child: Card(
              child: Container(
                  padding: const EdgeInsets.all(10.0),
                  width: 440,
                  child: Column(
                    children: <Widget>[
                      Container(
                        margin: const EdgeInsets.fromLTRB(0, 0, 0, 10),
                        child: Column(
                          children: <Widget>[
                            Text('Nom:', style: TextStyle(color: Colors.black.withOpacity(0.8))),
                            Text(widget.users.firstName, style: Theme.of(context).textTheme.subtitle1)
                          ],
                        ),
                      ),
                      Container(
                        margin: const EdgeInsets.fromLTRB(0, 0, 0, 10),
                        child: Column(
                          children: <Widget>[
                            Text('Prénom:', style: TextStyle(color: Colors.black.withOpacity(0.8))),
                            Text(widget.users.lastName!, style: Theme.of(context).textTheme.subtitle1)
                          ],
                        ),
                      ),
                      Container(
                        margin: const EdgeInsets.fromLTRB(0, 0, 0, 10),
                        child: Column(
                          children: <Widget>[
                            Text('Login:', style: TextStyle(color: Colors.black.withOpacity(0.8))),
                            Text(widget.users.login, style: Theme.of(context).textTheme.subtitle1)
                          ],
                        ),
                      ),
                      Container(
                        margin: const EdgeInsets.fromLTRB(0, 0, 0, 10),
                        child: Column(
                          children: <Widget>[
                            Text('E-mail:', style: TextStyle(color: Colors.black.withOpacity(0.8))),
                            Text(widget.users.email, style: Theme.of(context).textTheme.subtitle1)
                          ],
                        ),
                      ),
                      Container(
                        margin: const EdgeInsets.fromLTRB(0, 0, 0, 10),
                        child: Column(
                          children: <Widget>[
                            Text('Téléphone:', style: TextStyle(color: Colors.black.withOpacity(0.8))),
                            Text(widget.users.phone, style: Theme.of(context).textTheme.subtitle1)
                          ],
                        ),
                      ),
                      Container(
                        margin: const EdgeInsets.fromLTRB(0, 0, 0, 10),
                        child: Column(
                          children: <Widget>[
                            Text('Adresse:', style: TextStyle(color: Colors.black.withOpacity(0.8))),
                            Text(widget.users.address, style: Theme.of(context).textTheme.subtitle1)
                          ],
                        ),
                      ),
                      Container(
                        margin: const EdgeInsets.fromLTRB(0, 0, 0, 10),
                        child: Column(
                          children: <Widget>[
                            Text('Ville:', style: TextStyle(color: Colors.black.withOpacity(0.8))),
                            Text(widget.users.city, style: Theme.of(context).textTheme.subtitle1)
                          ],
                        ),
                      ),
                      Container(
                        margin: const EdgeInsets.fromLTRB(0, 0, 0, 20),
                        child: Column(
                          children: <Widget>[
                            Text('Pays:', style: TextStyle(color: Colors.black.withOpacity(0.8))),
                            Text(widget.users.country, style: Theme.of(context).textTheme.subtitle1)
                          ],
                        ),
                      ),
                      Container(
                        margin: const EdgeInsets.fromLTRB(0, 0, 0, 10),
                        child: Column(
                          children: <Widget>[
                          Container(
                            margin: const EdgeInsets.fromLTRB(0, 0, 0, 10),
                            child: RaisedButton(
                              splashColor: Colors.red,
                              onPressed: () {
                                _navigateToEditScreen(context, widget.users);
                              },
                              child: const Text('Editer', style: TextStyle(color: Colors.white)),
                              color: Colors.blue,
                            )
                          ),
                          Container(
                              margin: const EdgeInsets.fromLTRB(0, 10, 0, 10),
                              child: RaisedButton(
                                splashColor: Colors.red,
                                onPressed: () {
                                  _confirmDialog();
                                },
                                child: const Text('Supprimer', style: TextStyle(color: Colors.white)),
                                color: Colors.red,
                              )
                          ),
                          ],
                        ),
                      ),
                    ],
                  )
              )
          ),
        ),
      ),
    );
  }

}